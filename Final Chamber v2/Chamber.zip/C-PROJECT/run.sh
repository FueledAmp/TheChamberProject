#!/bin/bash

./main 2>/dev/null
